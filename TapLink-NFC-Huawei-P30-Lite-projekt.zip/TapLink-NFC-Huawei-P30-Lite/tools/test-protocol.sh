#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/protocol-test
javac -d build/protocol-test app/src/main/java/pl/taplink/nfc/Type4NdefProtocol.java tools/TestNfcProtocol.java
java -cp build/protocol-test TestNfcProtocol
