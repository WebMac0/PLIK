import pl.taplink.nfc.Type4NdefProtocol;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Local test that does not require Android, NFC hardware or Gradle. */
public class TestNfcProtocol {
    static byte[] hex(String text) {
        byte[] bytes = new byte[text.length() / 2];
        for (int i = 0; i < bytes.length; i++)
            bytes[i] = (byte) Integer.parseInt(text.substring(i * 2, i * 2 + 2), 16);
        return bytes;
    }
    static void expect(byte[] received, byte[] expected) {
        if (!Arrays.equals(received, expected))
            throw new AssertionError("NFC APDU response mismatch");
    }
    static byte[] read(Type4NdefProtocol tag, String link, int offset, int len) {
        return tag.respond(new byte[] {0x00, (byte) 0xB0, (byte) (offset >> 8),
                (byte) offset, (byte) len}, link);
    }
    static byte[] appendStatus(byte[] data) {
        byte[] out = Arrays.copyOf(data, data.length + 2);
        out[out.length - 2] = (byte) 0x90;
        return out;
    }
    public static void main(String[] args) {
        Type4NdefProtocol tag = new Type4NdefProtocol();
        String url = "https://example.com/test?x=1";
        expect(tag.respond(hex("00A4040007D276000085010100"), url), hex("9000"));
        expect(tag.respond(hex("00A4000C02E103"), url), hex("9000"));
        byte[] cc = read(tag, url, 0, 15);
        if (cc.length != 17 || cc[0] != 0 || cc[1] != 0x0F)
            throw new AssertionError("Invalid CC file");
        expect(tag.respond(hex("00A4000C02E104"), url), hex("9000"));
        byte[] ndef = Type4NdefProtocol.ndefFile(url);
        int nlen = ((ndef[0] & 255) << 8) | (ndef[1] & 255);
        if (nlen != ndef.length - 2) throw new AssertionError("Bad NLEN");
        byte[] response = read(tag, url, 0, 2);
        expect(response, new byte[]{ndef[0], ndef[1], (byte) 0x90, 0x00});
        byte[] part = read(tag, url, 2, Math.min(120, nlen));
        expect(part, appendStatus(Arrays.copyOfRange(ndef, 2, 2 + part.length - 2)));
        if (part[part.length - 2] != (byte) 0x90 || part[part.length - 1] != 0)
            throw new AssertionError("Missing success status");
        tag.reset();
        expect(read(tag, url, 0, 2), hex("6986"));
        String longUrl = "https://example.org/" + "abc".repeat(100);
        byte[] largeFile = Type4NdefProtocol.ndefFile(longUrl);
        if (largeFile[2] != (byte)0xC1) throw new AssertionError("Expected long NDEF record");
        System.out.println("OK: Type 4 NDEF APDU protocol, short + long URLs");
    }
}
