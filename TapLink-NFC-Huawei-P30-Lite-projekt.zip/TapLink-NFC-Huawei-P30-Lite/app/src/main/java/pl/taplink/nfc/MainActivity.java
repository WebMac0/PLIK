package pl.taplink.nfc;

import android.app.Activity;
import android.content.ComponentName;
import android.nfc.cardemulation.CardEmulation;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

/** A simple, dependency-free Android UI for sending and receiving URL over NFC. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 19, 32);
    private static final int PANEL = Color.rgb(25, 36, 55);
    private static final int WHITE = Color.rgb(244, 249, 255);
    private static final int DIM = Color.rgb(158, 173, 194);
    private static final int MINT = Color.rgb(113, 240, 189);
    private static final int BORDER = Color.rgb(50, 70, 91);
    private EditText urlInput;
    private TextView stateText;
    private TextView infoText;
    private Button shareButton;
    private Button receiveButton;
    private NfcAdapter adapter;
    private SharedPreferences prefs;
    private boolean receiving;
    private final AtomicBoolean readingBusy = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        adapter = NfcAdapter.getDefaultAdapter(this);
        prefs = getSharedPreferences("taplink", MODE_PRIVATE);
        // Do not silently keep sharing after the app was force-stopped in another session.
        prefs.edit().putBoolean("sharing", false).commit();
        buildUi();
        refreshUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);

        TextView label = text("◉  TAPLINK NFC", 14, MINT, Typeface.BOLD);
        root.addView(label);
        addGap(root, 23);
        TextView title = text("Link na dotyk.", 31, WHITE, Typeface.BOLD);
        root.addView(title);
        addGap(root, 11);
        TextView subtitle = text("Wpisz adres strony, włącz udostępnianie i zbliż telefony. Bez naklejek NFC.", 15, DIM, Typeface.NORMAL);
        subtitle.setLineSpacing(dp(5), 1.0f);
        root.addView(subtitle);
        addGap(root, 28);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(22), dp(18), dp(22));
        panel.setBackground(background(PANEL, 22, PANEL, 0));
        root.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        panel.addView(text("TWÓJ LINK", 12, DIM, Typeface.BOLD));
        addGap(panel, 12);
        urlInput = new EditText(this);
        urlInput.setText(prefs.getString("url", "https://example.com"));
        urlInput.setSingleLine(true);
        urlInput.setTextSize(16);
        urlInput.setSelectAllOnFocus(true);
        urlInput.setTextColor(WHITE);
        urlInput.setHintTextColor(DIM);
        urlInput.setHint("https://twoja-strona.pl");
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        urlInput.setBackground(background(BG, 13, BORDER, 1));
        panel.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(56)));
        addGap(panel, 16);

        shareButton = button("WŁĄCZ UDOSTĘPNIANIE NFC", BG, MINT, MINT);
        shareButton.setOnClickListener(view -> startSharing());
        panel.addView(shareButton, new LinearLayout.LayoutParams(-1, dp(54)));
        addGap(panel, 11);

        receiveButton = button("ODBIERZ LINK PRZEZ NFC", WHITE, PANEL, BORDER);
        receiveButton.setOnClickListener(view -> startReceiving());
        panel.addView(receiveButton, new LinearLayout.LayoutParams(-1, dp(54)));
        addGap(panel, 11);

        Button offButton = button("WYŁĄCZ NFC W APLIKACJI", DIM, PANEL, BORDER);
        offButton.setOnClickListener(view -> {
            stopReceiving();
            disableSharing();
            refreshUi();
        });
        panel.addView(offButton, new LinearLayout.LayoutParams(-1, dp(48)));

        addGap(root, 19);
        LinearLayout statusPanel = new LinearLayout(this);
        statusPanel.setOrientation(LinearLayout.VERTICAL);
        statusPanel.setPadding(dp(18), dp(18), dp(18), dp(18));
        statusPanel.setBackground(background(PANEL, 18, PANEL, 0));
        root.addView(statusPanel, new LinearLayout.LayoutParams(-1, -2));

        stateText = text("NIEAKTYWNE", 14, DIM, Typeface.BOLD);
        statusPanel.addView(stateText);
        addGap(statusPanel, 9);
        infoText = text("Naciśnij przycisk, aby rozpocząć.", 14, DIM, Typeface.NORMAL);
        infoText.setLineSpacing(dp(3), 1.0f);
        statusPanel.addView(infoText);
        addGap(root, 19);

        TextView foot = text("Wysyłanie wymaga Androida z NFC i HCE. Telefon odbierający musi mieć włączone NFC. iPhone zwykle wyświetli powiadomienie z linkiem, a niektóre Androidy potrzebują trybu „Odbierz link” w tej aplikacji. Udostępnianie wyłącza się po opuszczeniu ekranu.", 13, DIM, Typeface.NORMAL);
        foot.setLineSpacing(dp(4), 1.0f);
        root.addView(foot);
        setContentView(scroll);
    }

    private void startSharing() {
        if (!checkNfc(true)) return;
        String link = normalizedUrl(urlInput.getText().toString());
        if (link == null) {
            urlInput.setError("Podaj poprawny adres http:// lub https:// (maks. 850 bajtów).");
            return;
        }
        stopReceiving();
        prefs.edit().putString("url", link).putBoolean("sharing", true).commit();
        urlInput.setText(link);
        // Keep the screen awake while armed: HCE is not reliable with screen off.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideKeyboard();
        preferHceWhileOpen();
        refreshUi();
    }

    private void startReceiving() {
        if (!checkNfc(false)) return;
        disableSharing();
        if (receiving) {
            stopReceiving();
            refreshUi();
            return;
        }
        receiving = true;
        readingBusy.set(false);
        int flags = NfcAdapter.FLAG_READER_NFC_A
                | NfcAdapter.FLAG_READER_NFC_B
                | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK;
        try {
            adapter.enableReaderMode(this, this::onTagDiscovered, flags, null);
            hideKeyboard();
            refreshUi();
        } catch (RuntimeException ex) {
            receiving = false;
            Toast.makeText(this, "Nie udało się uruchomić czytnika NFC.", Toast.LENGTH_LONG).show();
            refreshUi();
        }
    }

    private void onTagDiscovered(android.nfc.Tag tag) {
        if (!readingBusy.compareAndSet(false, true)) return;
        try {
            String link = NfcReceiver.readUrl(tag);
            runOnUiThread(() -> {
                if (!receiving) return;
                stopReceiving();
                refreshUi();
                try {
                    Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                    startActivity(browser);
                } catch (RuntimeException ex) {
                    Toast.makeText(this, "Brak aplikacji do otwarcia tej strony.", Toast.LENGTH_LONG).show();
                }
            });
        } catch (IOException | RuntimeException e) {
            readingBusy.set(false);
            runOnUiThread(() -> {
                if (receiving) {
                    infoText.setText("Nie udało się odczytać linku: " + e.getMessage()
                            + " Spróbuj zbliżyć telefony ponownie.");
                }
            });
        }
    }

    private void stopReceiving() {
        if (!receiving) return;
        receiving = false;
        try {
            if (adapter != null) adapter.disableReaderMode(this);
        } catch (RuntimeException ignored) { }
    }

    private void disableSharing() {
        prefs.edit().putBoolean("sharing", false).commit();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        clearHcePreference();
    }

    /** Give this foreground application priority over other emulated cards, if permitted. */
    private void preferHceWhileOpen() {
        if (adapter == null || !prefs.getBoolean("sharing", false)) return;
        try {
            CardEmulation.getInstance(adapter).setPreferredService(
                    this, new ComponentName(this, LinkHceService.class));
        } catch (RuntimeException ignored) {
            // Some EMUI builds restrict changing the preferred HCE service.
        }
    }

    private void clearHcePreference() {
        if (adapter == null) return;
        try {
            CardEmulation.getInstance(adapter).unsetPreferredService(this);
        } catch (RuntimeException ignored) { }
    }

    private boolean checkNfc(boolean asSender) {
        if (adapter == null) {
            Toast.makeText(this, "Ten telefon nie ma NFC.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!adapter.isEnabled()) {
            Toast.makeText(this, "Włącz NFC w ustawieniach telefonu.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (asSender && !getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)) {
            Toast.makeText(this, "Ten telefon nie obsługuje emulacji karty HCE.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void refreshUi() {
        boolean sharing = prefs.getBoolean("sharing", false);
        if (receiving) {
            stateText.setText("●  ODBIÓR NFC WŁĄCZONY");
            stateText.setTextColor(MINT);
            infoText.setText("Zbliż do tego telefonu telefon udostępniający link. Strona otworzy się w przeglądarce.");
            receiveButton.setText("ZAKOŃCZ ODBIERANIE");
        } else if (sharing) {
            stateText.setText("●  UDOSTĘPNIANIE WŁĄCZONE");
            stateText.setTextColor(MINT);
            infoText.setText("Zbliż tyły telefonów. Drugi telefon musi mieć NFC i odblokowany ekran. Link: "
                    + prefs.getString("url", ""));
            receiveButton.setText("ODBIERZ LINK PRZEZ NFC");
        } else {
            stateText.setText("○  NFC NIEAKTYWNE");
            stateText.setTextColor(DIM);
            infoText.setText("Wpisz link, a potem wybierz udostępnianie lub odbieranie.");
            receiveButton.setText("ODBIERZ LINK PRZEZ NFC");
        }
    }

    /** Only HTTP(S) addresses are shared; missing scheme defaults to https. */
    private static String normalizedUrl(String value) {
        String text = value.trim();
        if (text.isEmpty()) return null;
        if (!text.contains("://")) text = "https://" + text;
        try {
            URI uri = new URI(text);
            String scheme = uri.getScheme();
            if (scheme == null || (!scheme.equalsIgnoreCase("https")
                    && !scheme.equalsIgnoreCase("http"))
                    || uri.getHost() == null || uri.getHost().isEmpty()
                    || uri.getUserInfo() != null || text.getBytes(StandardCharsets.UTF_8).length > 850) {
                return null;
            }
            return text;
        } catch (java.net.URISyntaxException ex) {
            return null;
        }
    }

    private void hideKeyboard() {
        InputMethodManager manager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        if (manager != null && getCurrentFocus() != null)
            manager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        urlInput.clearFocus();
    }

    private TextView text(String str, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(str);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", style));
        return v;
    }

    private Button button(String str, int color, int bg, int border) {
        Button b = new Button(this);
        b.setText(str);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setTextColor(color);
        b.setGravity(Gravity.CENTER);
        b.setBackground(background(bg, 13, border, 1));
        return b;
    }

    private GradientDrawable background(int fill, int radius, int stroke, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), stroke);
        return d;
    }

    private void addGap(LinearLayout layout, int height) {
        View gap = new View(this);
        layout.addView(gap, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        preferHceWhileOpen();
    }

    @Override
    protected void onPause() {
        clearHcePreference();
        super.onPause();
    }

    @Override
    protected void onStop() {
        stopReceiving();
        disableSharing();
        super.onStop();
    }
}
