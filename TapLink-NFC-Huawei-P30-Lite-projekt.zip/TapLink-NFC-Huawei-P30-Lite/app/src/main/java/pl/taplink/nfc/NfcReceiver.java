package pl.taplink.nfc;

import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Reads the URL from a Type 4 NDEF tag, including one emulated by this app. */
public final class NfcReceiver {
    private static final byte[] SELECT_AID = hex("00A4040007D276000085010100");
    private static final byte[] SELECT_NDEF_FILE = hex("00A4000C02E104");

    private NfcReceiver() {}

    public static String readUrl(Tag tag) throws IOException {
        IsoDep iso = IsoDep.get(tag);
        if (iso == null) throw new IOException("To nie jest tag NFC typu 4.");
        try {
            iso.connect();
            iso.setTimeout(3000);
            exchange(iso, SELECT_AID);
            exchange(iso, SELECT_NDEF_FILE);
            byte[] lengthBytes = readBinary(iso, 0, 2);
            if (lengthBytes.length != 2) throw new IOException("Brak danych NDEF.");
            int nlen = ((lengthBytes[0] & 0xFF) << 8) | (lengthBytes[1] & 0xFF);
            if (nlen < 5 || nlen > 1022) throw new IOException("Nieprawidłowa długość linku.");
            ByteArrayOutputStream out = new ByteArrayOutputStream(nlen);
            int offset = 2;
            while (out.size() < nlen) {
                int count = Math.min(200, nlen - out.size());
                byte[] part = readBinary(iso, offset, count);
                if (part.length != count) throw new IOException("Niepełny odczyt NFC.");
                out.write(part, 0, part.length);
                offset += count;
            }
            return decodeUri(out.toByteArray());
        } finally {
            try { iso.close(); } catch (IOException ignored) { }
        }
    }

    private static byte[] readBinary(IsoDep iso, int offset, int length) throws IOException {
        byte[] cmd = {0x00, (byte) 0xB0, (byte)(offset >> 8), (byte)offset, (byte)length};
        return exchange(iso, cmd);
    }

    private static byte[] exchange(IsoDep iso, byte[] command) throws IOException {
        byte[] response = iso.transceive(command);
        if (response.length < 2 || response[response.length - 2] != (byte) 0x90
                || response[response.length - 1] != 0x00) {
            throw new IOException("Tag nie odpowiada w oczekiwanym formacie NFC.");
        }
        return Arrays.copyOf(response, response.length - 2);
    }

    static String decodeUri(byte[] bytes) throws IOException {
        if (bytes.length < 5 || (bytes[0] & 0x07) != 0x01)
            throw new IOException("Nie znaleziono rekordu NDEF URI.");
        boolean shortRecord = (bytes[0] & 0x10) != 0;
        boolean idPresent = (bytes[0] & 0x08) != 0;
        int typeLength = bytes[1] & 0xFF;
        int payloadLength;
        int position;
        if (shortRecord) {
            payloadLength = bytes[2] & 0xFF;
            position = 3;
        } else {
            if (bytes.length < 6) throw new IOException("Uszkodzony NDEF.");
            long longLength = ((long)(bytes[2] & 0xFF) << 24)
                    | ((long)(bytes[3] & 0xFF) << 16)
                    | ((long)(bytes[4] & 0xFF) << 8)
                    | (bytes[5] & 0xFF);
            if (longLength > 1024) throw new IOException("Za długi rekord URI.");
            payloadLength = (int) longLength;
            position = 6;
        }
        int idLength = 0;
        if (idPresent) {
            if (position >= bytes.length) throw new IOException("Uszkodzony NDEF.");
            idLength = bytes[position++] & 0xFF;
        }
        if (typeLength != 1 || position + typeLength + idLength + payloadLength > bytes.length
                || payloadLength < 2 || bytes[position] != 0x55)
            throw new IOException("NDEF nie zawiera adresu WWW.");
        position += typeLength + idLength;
        int prefixCode = bytes[position++] & 0xFF;
        String prefix;
        switch (prefixCode) {
            case 0: prefix = ""; break;
            case 1: prefix = "http://www."; break;
            case 2: prefix = "https://www."; break;
            case 3: prefix = "http://"; break;
            case 4: prefix = "https://"; break;
            default: throw new IOException("Nieznany skrót URL.");
        }
        String url = prefix + new String(bytes, position, payloadLength - 1, StandardCharsets.UTF_8);
        try {
            URI parsed = new URI(url);
            String scheme = parsed.getScheme();
            if (scheme == null || (!scheme.equalsIgnoreCase("https") && !scheme.equalsIgnoreCase("http"))
                    || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IOException("NFC zawiera nieobsługiwany adres.");
            }
        } catch (java.net.URISyntaxException ex) {
            throw new IOException("Niepoprawny adres WWW.", ex);
        }
        return url;
    }

    private static byte[] hex(String s) {
        byte[] out = new byte[s.length()/2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte)Integer.parseInt(s.substring(i*2, i*2+2), 16);
        }
        return out;
    }
}
