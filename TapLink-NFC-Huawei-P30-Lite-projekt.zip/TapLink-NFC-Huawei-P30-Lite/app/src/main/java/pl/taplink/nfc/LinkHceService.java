package pl.taplink.nfc;

import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;

/** Presents the currently armed URL as a read-only NFC Type 4 NDEF tag. */
public final class LinkHceService extends HostApduService {
    private final Type4NdefProtocol tag = new Type4NdefProtocol();

    @Override
    public byte[] processCommandApdu(byte[] commandApdu, Bundle extras) {
        boolean sharing = getSharedPreferences("taplink", MODE_PRIVATE)
                .getBoolean("sharing", false);
        if (!sharing) return new byte[]{0x69, (byte) 0x85};
        String url = getSharedPreferences("taplink", MODE_PRIVATE)
                .getString("url", "https://example.com");
        try {
            return tag.respond(commandApdu, url);
        } catch (IllegalArgumentException ex) {
            return new byte[]{0x6A, (byte) 0x80};
        }
    }

    @Override
    public void onDeactivated(int reason) {
        tag.reset();
    }
}
