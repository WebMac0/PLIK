package pl.taplink.nfc;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * NFC Forum Type 4 Tag (NDEF read-only) implemented using ISO 7816-4 APDUs.
 * Plain Java for easy testing. Only URI record is supported.
 */
public final class Type4NdefProtocol {
    private static final byte[] OK = {(byte) 0x90, 0x00};
    private static final byte[] FILE_NOT_FOUND = {0x6A, (byte) 0x82};
    private static final byte[] WRONG_PARAMS = {0x6B, 0x00};
    private static final byte[] WRONG_LENGTH = {0x67, 0x00};
    private static final byte[] NOT_ALLOWED = {0x69, (byte) 0x86};
    private static final byte[] UNKNOWN_INS = {0x6D, 0x00};
    private static final byte[] AID = {
            (byte) 0xD2, 0x76, 0x00, 0x00, (byte) 0x85, 0x01, 0x01
    };
    private static final byte[] CC_FILE = {
            0x00, 0x0F,               // 15-byte capability container
            0x20,                     // NDEF Mapping version 2.0
            0x00, (byte) 0xF6,        // maximum R-APDU size
            0x00, (byte) 0xF6,        // maximum C-APDU size
            0x04, 0x06,               // NDEF File Control TLV
            (byte) 0xE1, 0x04,        // NDEF file ID
            0x04, 0x00,               // 1024-byte max NDEF file size
            0x00,                     // read permitted
            (byte) 0xFF              // write forbidden
    };
    private static final int NONE = 0;
    private static final int CC = 1;
    private static final int NDEF = 2;
    private int selectedFile = NONE;
    private boolean selectedApp = false;

    public synchronized void reset() {
        selectedApp = false;
        selectedFile = NONE;
    }

    public synchronized byte[] respond(byte[] apdu, String url) {
        if (apdu == null || apdu.length < 4) return WRONG_LENGTH;
        if ((apdu[0] & 0xFF) != 0) return UNKNOWN_INS;
        final int ins = apdu[1] & 0xFF;

        if (ins == 0xA4) {
            if (apdu.length < 5) return WRONG_LENGTH;
            final int p1 = apdu[2] & 0xFF;
            final int lc = apdu[4] & 0xFF;
            if (apdu.length < 5 + lc) return WRONG_LENGTH;

            if (p1 == 0x04 && lc == AID.length) {
                boolean aidMatches = true;
                for (int i = 0; i < AID.length; i++) {
                    if (apdu[5 + i] != AID[i]) aidMatches = false;
                }
                reset();
                if (aidMatches) {
                    selectedApp = true;
                    return OK;
                }
                return FILE_NOT_FOUND;
            }
            if (!selectedApp) return NOT_ALLOWED;
            if (p1 == 0x00 && lc == 2) {
                final int fileId = ((apdu[5] & 0xFF) << 8) | (apdu[6] & 0xFF);
                if (fileId == 0xE103) {
                    selectedFile = CC;
                    return OK;
                }
                if (fileId == 0xE104) {
                    selectedFile = NDEF;
                    return OK;
                }
                return FILE_NOT_FOUND;
            }
            return WRONG_PARAMS;
        }

        if (ins == 0xB0) {
            if (!selectedApp || selectedFile == NONE) return NOT_ALLOWED;
            if (apdu.length != 5) return WRONG_LENGTH;
            int offset = ((apdu[2] & 0xFF) << 8) | (apdu[3] & 0xFF);
            int length = apdu[4] & 0xFF;
            if (length == 0) length = 256;
            byte[] file = selectedFile == CC ? CC_FILE : ndefFile(url);
            if (offset >= file.length) return WRONG_PARAMS;
            int available = Math.min(length, file.length - offset);
            byte[] result = Arrays.copyOfRange(file, offset, offset + available);
            return withSuccess(result);
        }
        return UNKNOWN_INS;
    }

    /** NLEN (2 bytes) + NDEF message with one URI record. */
    public static byte[] ndefFile(String url) {
        if (url == null) throw new IllegalArgumentException("Missing URL");
        byte[] uri = url.getBytes(StandardCharsets.UTF_8);
        if (uri.length > 850) throw new IllegalArgumentException("URL too long");
        int payloadLength = 1 + uri.length; // prefix code 0x00 + UTF-8 URL
        boolean shortRecord = payloadLength <= 255;
        int headerLength = shortRecord ? 5 : 8;
        int recordLength = headerLength + uri.length;
        byte[] output = new byte[2 + recordLength];
        output[0] = (byte) (recordLength >> 8);
        output[1] = (byte) recordLength;
        int i = 2;
        output[i++] = shortRecord ? (byte) 0xD1 : (byte) 0xC1; // MB ME [SR] TNF=1
        output[i++] = 0x01; // length of type
        if (shortRecord) {
            output[i++] = (byte) payloadLength;
        } else {
            output[i++] = (byte) (payloadLength >>> 24);
            output[i++] = (byte) (payloadLength >>> 16);
            output[i++] = (byte) (payloadLength >>> 8);
            output[i++] = (byte) payloadLength;
        }
        output[i++] = 0x55; // URI type "U"
        output[i++] = 0x00; // no prefix compression, full https:// URL
        System.arraycopy(uri, 0, output, i, uri.length);
        return output;
    }

    private static byte[] withSuccess(byte[] data) {
        byte[] response = Arrays.copyOf(data, data.length + 2);
        response[response.length - 2] = (byte) 0x90;
        response[response.length - 1] = 0x00;
        return response;
    }
}
