plugins {
    id("com.android.application")
}

android {
    namespace = "pl.taplink.nfc"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.taplink.nfc"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
