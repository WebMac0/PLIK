# TapLink NFC (Android)

Prosta aplikacja Android do przesyłania linków przez zbliżenie dwóch telefonów NFC.

## Co robi

- **Wysyłanie:** wpisujesz URL, naciskasz „Włącz udostępnianie NFC” i przykładasz telefon do odbiorcy. Wysyłający telefon udaje **tag NFC Forum Type 4 z rekordem NDEF URI**. Nie potrzeba naklejki NFC.
- **Odbieranie:** na drugim Androidzie, jeśli system nie reaguje sam na przyłożenie, można uruchomić **tę samą aplikację** i nacisnąć „Odbierz link przez NFC”. Po odczycie strona uruchomi się w przeglądarce.
- Wysłanie strony nie wymaga internetu, ale jej wyświetlenie w przeglądarce zwykle już tak.
- Obsługiwane linki: http i https, do 850 bajtów UTF-8.
- Aplikacja nie potrzebuje dostępu do internetu ani konta. URL jest przechowywany lokalnie.
- Udostępnianie wyłącza się po opuszczeniu ekranu aplikacji.

## Jak uzyskać APK

1. Zainstaluj bezpłatne **Android Studio** na komputerze: https://developer.android.com/studio
2. Rozpakuj ZIP i w Android Studio kliknij **Open**, następnie wskaż folder `TapLink-NFC`.
3. Pozwól Android Studio pobrać potrzebne narzędzia Gradle i Android SDK. Jeśli zapyta o dystrybucję Gradle, użyj Gradle 8.9 (AGP 8.7.3) i JDK 17.
4. Kliknij **Build > Build Bundle(s) / APK(s) > Build APK(s)** (nazwa może się trochę różnić między wersjami).
5. APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.
6. Przenieś APK na Androida i zainstaluj, jeśli telefon pozwala na instalację własnej aplikacji. Na odbiorcy można również zainstalować to samo APK.

## Uruchomienie

1. Włącz NFC i odblokuj oba telefony.
2. Na nadawcy uruchom TapLink NFC, wpisz stronę np. `https://example.com`, wybierz „Włącz udostępnianie NFC”.
3. Przyłóż tyły telefonów (anteny NFC bywają na różnych wysokościach); utrzymuj zbliżenie około 1–2 sekundy.
4. Jeśli nic się nie stanie na Androidzie odbierającym, uruchom na nim TapLink NFC i „Odbierz link przez NFC”, a potem zbliż telefony jeszcze raz.
5. Na iPhonie wspierającym odczyt NFC URL zwykle pojawi się powiadomienie, które należy dotknąć.

## Wymagania i ograniczenia

- Nadawca: Android 8.0+ z NFC i HCE, włączony i odblokowany ekran. Odbiorca z Androidem może mieć samo NFC bez HCE.
- Odbiorca: telefon z odpowiednią obsługą NFC, na iPhonie powiadomienie może wymagać dotknięcia. Nie ma gwarancji automatycznego otwierania witryny na każdym modelu. Niektóre Androidy zamiast odczytać tag próbują komunikacji telefon-telefon (stary Android Beam); tryb odbioru w aplikacji obchodzi to ograniczenie.
- iPhone nie jest wspierany jako nadawca przez ten projekt.
- Może występować konflikt między kilkoma aplikacjami HCE, które obsługują standardowy identyfikator NFC NDEF `D2760000850101`.
- Nie wykonano jeszcze testu na fizycznych telefonach. To kod źródłowy przygotowany do zbudowania, a nie gotowa instalka APK.

## Struktura

- `MainActivity.java` — ekran aplikacji, zapis URL, uruchomienie HCE i trybu czytnika.
- `LinkHceService.java` — systemowa usługa HCE.
- `Type4NdefProtocol.java` — protokół Type 4 Tag, APDU i zapis NDEF.
- `NfcReceiver.java` — ręczny odczyt NDEF przy użyciu IsoDep.

## Prywatność i bezpieczeństwo

Aplikacja przekazuje jedynie wpisany link. Nie zbiera kontaktów, zdjęć, wiadomości i lokalizacji. Nie udostępnia linku, kiedy nie jest włączony tryb wysyłania. Przed otwarciem linku od innej osoby upewnij się, że ufasz nadawcy.

## Budowanie instalatora bez Android Studio (GitHub Actions)

W projekcie znajduje się gotowy workflow: `.github/workflows/build-apk.yml`.
Kompiluje **natywną aplikację Android**, bez WebView, i udostępnia prawdziwy
instalator `app-debug.apk` podpisany standardowym kluczem deweloperskim.

1. Utwórz puste repozytorium na https://github.com/new (może być prywatne).
2. Wgraj do niego **zawartość** rozpakowanego folderu `TapLink-NFC`, również
   ukryty folder `.github`. Repozytorium ma zawierać plik `app/build.gradle.kts`
   i `.github/workflows/build-apk.yml`.
3. Wejdź w kartę **Actions** i wybierz `Build installable Android APK`.
4. Uruchom `Run workflow` (albo zaczekaj na build wywołany wgraniem plików).
5. Gdy build zostanie oznaczony jako udany, otwórz go i w sekcji **Artifacts**
   pobierz `TapLink-NFC-APK`. Rozpakuj pobrany plik ZIP, wewnątrz jest `app-debug.apk`.
6. Prześlij `app-debug.apk` na telefon z Androidem. Otwórz plik i zaakceptuj
   instalację tylko wtedy, gdy ufasz źródłu.

To jest **debug APK do testowania**, nie produkcyjny podpisany instalator.
Nie zostało jeszcze zweryfikowane działanie na fizycznych telefonach. Android
nie gwarantuje, że drugi telefon automatycznie odczyta emulowany tag NFC; w razie
potrzeby uruchom tryb odbioru w aplikacji na drugim urządzeniu.

## Wersja Huawei P30 Lite

Ten wariant projektu zawiera `START-HUAWEI-P30-LITE.txt`, wskazówki instalacyjne dla Huawei oraz próbę ustawienia usługi HCE jako preferowanej, gdy aplikacja jest na pierwszym planie. Samo NFC nie gwarantuje obsługi HCE. Do testowania protokołu bez Androida uruchom `tools/test-protocol.sh`.
